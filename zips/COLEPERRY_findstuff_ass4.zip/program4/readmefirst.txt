I did not implement anything for find<”text”> 
This also means that the <-f:XYZ> flag does not work

Other than those 2 things, I believe everything is working as expected :)

Also, I left a sleep(25) in the program so it is easier to test my "list", "kill" and interrupts

